
/* Script del esquema de la base de datos */

create database practica1;
use practica1;

create table region(
	num_region INTEGER(10) PRIMARY KEY,
	nom_region CHAR(100),
	area FLOAT(10)
);

create table departamento(
	num_departamento INTEGER(10) PRIMARY KEY,
	nom_departamento CHAR(100),
	area FLOAT(10),
	num_region INTEGER(10),
	FOREIGN KEY(num_region) REFERENCES region(num_region)
);

create table municipio(
	num_municipio INTEGER(10) PRIMARY KEY,
	nom_municipio CHAR(100),
	num_departamento INTEGER(10),
	FOREIGN KEY(num_departamento) REFERENCES departamento(num_departamento)
);

create table usuario(
	num_usuario INTEGER(10) PRIMARY KEY,
	nombre CHAR(100),
	apellido CHAR(100),
	fecha_nac DATE,
	direccion VARCHAR(500),
	credito FLOAT(10),
	num_municipio INTEGER(10),
	FOREIGN KEY(num_municipio) REFERENCES municipio(num_municipio)
);                  

create table compra(
	num_compra INTEGER(10) PRIMARY KEY,
	num_usuario INTEGER(10),
	fecha_compra DATE,
	FOREIGN KEY(num_usuario) REFERENCES usuario(num_usuario)
);     

create table categoria(
	num_categoria INTEGER(10) PRIMARY KEY,
	nom_categoria CHAR(100),
	num_categoria_superior INTEGER(10),
	FOREIGN KEY(num_categoria_superior) REFERENCES categoria(num_categoria)
);

create table producto(
	codigo_producto INTEGER(10) PRIMARY KEY,
	nom_producto CHAR(100),
	precio FLOAT(10),
	descripcion VARCHAR(500),
	num_categoria INTEGER(10),
	FOREIGN KEY(num_categoria) REFERENCES categoria(num_categoria)
);

create table detalle_compra(
	num_detalle_compra INTEGER(10) PRIMARY KEY,
	num_compra INTEGER(10),
	codigo_producto INTEGER(10),
	cantidad INTEGER(10),
	FOREIGN KEY(num_compra) REFERENCES compra(num_compra),
	FOREIGN KEY(codigo_producto) REFERENCES producto(codigo_producto)
);

/* Script de sentencias DML para inserción de registros */

insert into region values(1, "Centro", 250.6);
insert into region values(2, "Norte", 150.6);
insert into region values(3, "Sur", 220.6);
insert into region values(4, "Occidente", 50.6);
insert into region values(5, "Oriente", 200.6);

insert into departamento values(1, "Chimaltenango", 25.6 , 1);
insert into departamento values(2, "Guatemala", 25.6 , 1);
insert into departamento values(3, "Peten", 25.6 , 2);
insert into departamento values(4, "Alta Verapaz", 25.6 , 2);
insert into departamento values(5, "Escuintla", 25.6 , 3);
insert into departamento values(6, "Suchitepequez", 25.6 , 3);
insert into departamento values(7, "Quetzaltenango", 25.6 , 4);
insert into departamento values(8, "San Marcos", 25.6 , 4);
insert into departamento values(9, "Zacapa", 25.6 , 5);

insert into municipio values(1, "Chimaltenango", 25.6 , 1);
insert into departamento values(2, "Guatemala", 25.6 , 2);
insert into departamento values(3, "San Bebito", 25.6 , 3);
insert into departamento values(4, "Alta Verapaz", 25.6 , 2);
insert into departamento values(5, "Escuintla", 25.6 , 3);
insert into departamento values(6, "Suchitepequez", 25.6 , 3);
insert into departamento values(7, "Quetzaltenango", 25.6 , 4);
insert into departamento values(8, "San Marcos", 25.6 , 4);
insert into departamento values(9, "Zacapa", 25.6 , 5);